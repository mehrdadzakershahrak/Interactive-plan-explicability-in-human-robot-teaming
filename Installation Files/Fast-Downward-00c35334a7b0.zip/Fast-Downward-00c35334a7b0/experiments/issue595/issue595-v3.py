#! /usr/bin/env python
# -*- coding: utf-8 -*-

from main import main

main(revisions=["issue595-v1", "issue595-v3"])
