#! /usr/bin/env python
# -*- coding: utf-8 -*-

from main import main

main(revisions=["issue595-base", "issue595-v1"])
