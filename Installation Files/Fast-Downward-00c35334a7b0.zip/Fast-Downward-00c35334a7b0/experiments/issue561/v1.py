#! /usr/bin/env python
# -*- coding: utf-8 -*-

from main import main

main("issue561-base", "issue561-v1")
