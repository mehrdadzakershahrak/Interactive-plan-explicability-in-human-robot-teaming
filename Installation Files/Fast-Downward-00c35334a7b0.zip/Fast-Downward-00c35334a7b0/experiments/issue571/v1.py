#! /usr/bin/env python
# -*- coding: utf-8 -*-

from main import main

main(revisions=["issue571-base", "issue571-v1"])
