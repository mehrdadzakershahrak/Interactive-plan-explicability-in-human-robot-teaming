#! /usr/bin/env python
# -*- coding: utf-8 -*-

from main import main

main(revisions=["issue596-base", "issue596-v1"])
